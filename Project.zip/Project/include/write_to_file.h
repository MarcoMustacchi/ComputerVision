#ifndef WRITE2FILE_H
#define WRITE2FILE_H


void write_results_Detection(float value);
void write_results_Segmentation(float value);


#endif
