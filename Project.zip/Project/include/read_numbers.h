#ifndef READNUMBERS_H
#define READNUMBERS_H


std::vector<int> read_numbers(std::string file_name);


#endif
